## India Census - 2011

**[India Census 2011](census2011.co.in)** is the latest comprehensive census of India taken at the time of this writing. The source for this census is *[census2011.co.in](census2011.co.in)*. Hover over the states to see the statistics in the popup and the two graphs on the right. 

